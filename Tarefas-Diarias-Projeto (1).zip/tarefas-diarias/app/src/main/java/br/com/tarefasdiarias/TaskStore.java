package br.com.tarefasdiarias;

import android.content.Context;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

public class TaskStore {
    static List<Task> load(Context context) {
        List<Task> result = new ArrayList<>();
        String raw = context.getSharedPreferences("tasks", Context.MODE_PRIVATE).getString("items", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) result.add(Task.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) { }
        return result;
    }

    static void save(Context context, List<Task> tasks) {
        JSONArray a = new JSONArray();
        try { for (Task task : tasks) a.put(task.toJson()); } catch (Exception ignored) { }
        context.getSharedPreferences("tasks", Context.MODE_PRIVATE).edit().putString("items", a.toString()).apply();
    }
}
