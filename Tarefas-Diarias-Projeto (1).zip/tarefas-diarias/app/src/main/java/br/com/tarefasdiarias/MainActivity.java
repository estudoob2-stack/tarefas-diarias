package br.com.tarefasdiarias;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final List<Task> tasks = new ArrayList<>();
    LinearLayout list;
    TextView counter, empty;
    final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM 'às' HH:mm", new Locale("pt", "BR"));
    final int[] priorityColors = {0xFF43A047, 0xFFFFA000, 0xFFE53935};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        tasks.addAll(TaskStore.load(this));
        requestNotifications();
        buildScreen();
        render();
    }

    void buildScreen() {
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(0xFFFFF8F2);
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(20), dp(20), dp(20), dp(90));
        TextView title = text("Tarefas Diárias", 29, 0xFF2C2633); title.setTypeface(null, Typeface.BOLD);
        counter = text("", 15, 0xFF6750A4); counter.setPadding(0, dp(5), 0, dp(18));
        body.addView(title); body.addView(counter);
        ScrollView scroll = new ScrollView(this); list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list);
        body.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); root.addView(body);
        TextView add = text("＋", 32, Color.WHITE); add.setGravity(Gravity.CENTER); add.setBackground(makeBackground(0xFF6750A4, 30)); add.setElevation(dp(8)); add.setOnClickListener(v -> showEditor(null));
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM | Gravity.END); fp.setMargins(0,0,dp(22),dp(22)); root.addView(add, fp);
        setContentView(root);
    }

    void render() {
        list.removeAllViews();
        int pending = 0; for (Task t : tasks) if (!t.done) pending++;
        counter.setText(pending == 0 ? "Tudo em dia! ✨" : pending + (pending == 1 ? " tarefa pendente" : " tarefas pendentes"));
        tasks.sort((a,b) -> Boolean.compare(a.done,b.done));
        if (tasks.isEmpty()) {
            empty = text("Sua lista está vazia\nToque no + para criar a primeira tarefa", 17, 0xFF7A7280); empty.setGravity(Gravity.CENTER); empty.setPadding(0,dp(100),0,0); list.addView(empty);
            return;
        }
        for (Task task : tasks) list.addView(taskCard(task));
    }

    View taskCard(Task task) {
        LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(14),dp(12),dp(10),dp(12)); card.setBackground(makeBackground(Color.WHITE, 18)); card.setElevation(dp(2));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,0,0,dp(12)); card.setLayoutParams(cp);
        CheckBox check = new CheckBox(this); check.setChecked(task.done); check.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{0xFF6750A4,0xFF8A8190}));
        LinearLayout words = new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL);
        TextView name = text(task.title, 18, task.done ? 0xFF99929C : 0xFF2C2633); if (task.done) name.setPaintFlags(name.getPaintFlags() | 16); words.addView(name);
        String info = task.reminderAt > 0 ? dateFormat.format(new Date(task.reminderAt)) : "Sem lembrete";
        TextView meta = text("●  " + info, 13, priorityColors[task.priority]); meta.setPadding(0,dp(5),0,0); words.addView(meta);
        TextView menu = text("⋮", 28, 0xFF6750A4); menu.setGravity(Gravity.CENTER); menu.setOnClickListener(v -> taskMenu(task));
        card.addView(check, new LinearLayout.LayoutParams(dp(48),dp(48))); card.addView(words,new LinearLayout.LayoutParams(0,-2,1)); card.addView(menu,new LinearLayout.LayoutParams(dp(42),dp(48)));
        check.setOnCheckedChangeListener((b,on) -> { task.done=on; if(on) cancel(this,task); else schedule(this,task); saveAndRender(); });
        card.setOnClickListener(v -> showEditor(task)); return card;
    }

    void taskMenu(Task task) {
        new AlertDialog.Builder(this).setItems(new String[]{"Editar", "Excluir"}, (d,which) -> {
            if (which == 0) showEditor(task); else new AlertDialog.Builder(this).setTitle("Excluir tarefa?").setMessage(task.title).setNegativeButton("Cancelar",null).setPositiveButton("Excluir",(x,y)->{cancel(this,task);tasks.remove(task);saveAndRender();}).show();
        }).show();
    }

    void showEditor(Task existing) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(24),dp(8),dp(24),0);
        EditText input = new EditText(this); input.setHint("Ex.: Tomar remédio"); if(existing!=null) input.setText(existing.title); box.addView(input);
        Calendar selected = Calendar.getInstance(); if(existing!=null && existing.reminderAt>0) selected.setTimeInMillis(existing.reminderAt);
        TextView when = text(existing!=null && existing.reminderAt>0 ? dateFormat.format(selected.getTime()) : "Escolher data e horário",16,0xFF6750A4); when.setPadding(0,dp(18),0,dp(18)); box.addView(when);
        final boolean[] useReminder = {existing != null && existing.reminderAt > 0};
        when.setOnClickListener(v -> new DatePickerDialog(this,(view,y,m,d)->{ selected.set(y,m,d); new TimePickerDialog(this,(tv,h,min)->{selected.set(Calendar.HOUR_OF_DAY,h);selected.set(Calendar.MINUTE,min);selected.set(Calendar.SECOND,0);useReminder[0]=true;when.setText(dateFormat.format(selected.getTime()));},selected.get(Calendar.HOUR_OF_DAY),selected.get(Calendar.MINUTE),true).show();},selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show());
        Spinner priority = new Spinner(this); priority.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Prioridade baixa 🟢","Prioridade média 🟠","Prioridade alta 🔴"})); if(existing!=null) priority.setSelection(existing.priority); box.addView(priority);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(existing==null?"Nova tarefa":"Editar tarefa").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",null).create();
        dialog.setOnShowListener(x -> dialog.getButton(-1).setOnClickListener(v -> { String value=input.getText().toString().trim(); if(value.isEmpty()){input.setError("Digite o nome da tarefa");return;} long alarm=useReminder[0]?selected.getTimeInMillis():0; if(existing==null){Task t=new Task(System.currentTimeMillis(),value,alarm,priority.getSelectedItemPosition(),false);tasks.add(t);schedule(this,t);}else{cancel(this,existing);existing.title=value;existing.reminderAt=alarm;existing.priority=priority.getSelectedItemPosition();if(!existing.done)schedule(this,existing);} saveAndRender();dialog.dismiss(); })); dialog.show();
    }

    void saveAndRender(){ TaskStore.save(this,tasks); render(); }
    TextView text(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
    android.graphics.drawable.GradientDrawable makeBackground(int color,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}

    void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50);}
    static PendingIntent alarmIntent(Context c,Task t){Intent i=new Intent(c,ReminderReceiver.class).putExtra("title",t.title).putExtra("id",t.id);return PendingIntent.getBroadcast(c,(int)t.id,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
    static void schedule(Context c,Task t){if(t.reminderAt<=System.currentTimeMillis())return;AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);try{if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms())am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.reminderAt,alarmIntent(c,t));else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.reminderAt,alarmIntent(c,t));}catch(SecurityException e){am.set(AlarmManager.RTC_WAKEUP,t.reminderAt,alarmIntent(c,t));}}
    static void cancel(Context c,Task t){((AlarmManager)c.getSystemService(ALARM_SERVICE)).cancel(alarmIntent(c,t));}
}
