package br.com.tarefasdiarias;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        for (Task task : TaskStore.load(context)) if (!task.done && task.reminderAt > System.currentTimeMillis()) MainActivity.schedule(context, task);
    }
}
