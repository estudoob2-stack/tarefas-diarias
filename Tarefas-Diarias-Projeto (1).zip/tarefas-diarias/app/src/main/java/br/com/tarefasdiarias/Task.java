package br.com.tarefasdiarias;

import org.json.JSONException;
import org.json.JSONObject;

public class Task {
    long id;
    String title;
    long reminderAt;
    int priority;
    boolean done;

    Task(long id, String title, long reminderAt, int priority, boolean done) {
        this.id = id; this.title = title; this.reminderAt = reminderAt;
        this.priority = priority; this.done = done;
    }

    JSONObject toJson() throws JSONException {
        return new JSONObject().put("id", id).put("title", title)
                .put("reminderAt", reminderAt).put("priority", priority).put("done", done);
    }

    static Task fromJson(JSONObject j) {
        return new Task(j.optLong("id"), j.optString("title"), j.optLong("reminderAt"),
                j.optInt("priority", 1), j.optBoolean("done"));
    }
}
