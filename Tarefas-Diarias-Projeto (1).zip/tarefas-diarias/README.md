# Tarefas Diárias

Aplicativo Android offline para checklist de tarefas com prioridades coloridas e lembretes locais.

## Recursos

- Criar, editar, concluir e excluir tarefas
- Prioridades baixa, média e alta
- Data e horário opcionais
- Notificações de lembrete
- Dados salvos somente no aparelho
- Restauração dos lembretes após reiniciar o celular

## Gerar o APK

Abra o projeto no Android Studio e use **Build > Build APK(s)**. O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.
